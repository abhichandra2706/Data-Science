


SELECT  COUNT([Record_ID]) as [Record_Count],[Course_Name],[University],[Difficulty_Level],[Course_Rating],[Course_URL],[Course_Description],[Skills]
FROM [BDS].[dbo].[Coursera_BDS]
GROUP BY [Course_Name],[University],[Difficulty_Level],[Course_Rating],[Course_URL],[Course_Description],[Skills]
HAVING COUNT([Record_ID]) >1
Order by [Record_Count] desc