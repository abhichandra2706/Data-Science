SELECT [Course_Name], COUNT([Course_Name]) as [Course_Name_Count]
FROM [BDS].[dbo].[Coursera_BDS]
GROUP BY [Course_Name]
HAVING COUNT([Course_Name])>1
Order by [Course_Name_Count] desc

