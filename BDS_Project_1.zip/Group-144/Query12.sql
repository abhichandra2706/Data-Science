SELECT [Course_Description], COUNT([Course_Description]) as [Course_Description_Count]
FROM [BDS].[dbo].[Coursera_BDS]
GROUP BY [Course_Description]
HAVING COUNT([Course_Description])>1
Order by [Course_Description_Count] desc