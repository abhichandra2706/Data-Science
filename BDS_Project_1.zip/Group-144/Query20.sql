CREATE TABLE Four_WayShared_Course_URL(
	Course_URL_ID int IDENTITY(1,1) PRIMARY KEY,
	Course_URL varchar(200)
);