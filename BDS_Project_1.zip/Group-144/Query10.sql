SELECT [Course_URL], COUNT([Course_URL]) as [Course_URL_Count]
FROM [BDS].[dbo].[Coursera_BDS]
GROUP BY [Course_URL]
HAVING COUNT([Course_URL])>1
Order by [Course_URL] desc