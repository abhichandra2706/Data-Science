CREATE TABLE METADATA (
	 Record_ID int PRIMARY KEY,
	 Course_Desc_ID int,
	 Skills_ID int,
	 Course_Name_ID int,
	 University_ID int,
	 Difficulty_ID int,
	 Course_URL_ID int
);