--INSERT INTO Two_WayShared_Skills (Skills)
--SELECT [Skills] FROM [BDS].[dbo].[Coursera_BDS]
--GROUP BY [Skills] HAVING COUNT([Skills])>=1



--INSERT INTO Four_WayShared_Course_Name (Course_Name)
--SELECT [Course_Name] FROM [BDS].[dbo].[Coursera_BDS]
--GROUP BY [Course_Name] HAVING COUNT([Course_Name])>=1

--INSERT INTO Eight_WayShared_University (University)
--SELECT [University] FROM [BDS].[dbo].[Coursera_BDS]
--GROUP BY [University] HAVING COUNT([University])>=1

--INSERT INTO Eight_WayShared_Difficulty (Difficulty_Level)
--SELECT [Difficulty_Level] FROM [BDS].[dbo].[Coursera_BDS]
--GROUP BY [Difficulty_Level] HAVING COUNT([Difficulty_Level])>=1

--INSERT INTO Four_WayShared_Course_URL (Course_URL)
--SELECT [Course_URL] FROM [BDS].[dbo].[Coursera_BDS]
--GROUP BY [Course_URL] HAVING COUNT([Course_URL])>=1


CREATE TABLE PrivateNode(
	Record_ID int PRIMARY KEY,
	Course_Rating numeric(3,1)
);

INSERT INTO PrivateNode (Record_ID,Course_Rating)
SELECT Record_ID, Course_Rating FROM [BDS].[dbo].[Coursera_BDS]