SELECT [Difficulty_Level], COUNT([Difficulty_Level]) as [Difficulty_Level_Count]
FROM [BDS].[dbo].[Coursera_BDS]
GROUP BY [Difficulty_Level]
HAVING COUNT([Difficulty_Level])>1
Order by [Difficulty_Level_Count] desc