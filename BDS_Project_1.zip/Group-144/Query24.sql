DECLARE  @Record_ID int;
DECLARE	 @Course_Desc_ID int,
DECLARE	 @Skills_ID int,
DECLARE	 @Course_Name_ID int,
DECLARE	 @University_ID int,
DECLARE	 @Difficulty_ID int,
DECLARE	 @Course_URL_ID int

select Record_ID,Course_Desc_ID,Skills_ID,Course_Name_ID,University_ID,Difficulty_ID,Course_URL_ID
INTO @Record_ID, @Course_Desc_ID, @Skills_ID,@Course_Name_ID, @University_ID, @Difficulty_ID, @Course_URL_ID
From METADATA
where Record_ID = 10

Select Course_Description
from Two_WayShared_Course_Description where Course_Desc_ID = @Course_Desc_ID

