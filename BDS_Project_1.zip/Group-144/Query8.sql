SELECT [University], COUNT([University]) as [University_Count]
FROM [BDS].[dbo].[Coursera_BDS]
GROUP BY [University]
HAVING COUNT([University])>1
Order by [University_Count] desc