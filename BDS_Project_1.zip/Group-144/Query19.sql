SELECT *
FROM [BDS].[dbo].[Coursera_BDS]
where [Course_Name]= 'Google Cloud Platform Fundamentals: Core Infrastructure'
