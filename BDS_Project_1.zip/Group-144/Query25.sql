DECLARE @result1 TABLE (id  INT, Desc_ID INT, S_ID INT,Name_ID  INT, U_ID INT, D_ID INT, C_ID INT)

INSERT INTO @result1
SELECT Record_ID,Course_Desc_ID,Skills_ID,Course_Name_ID,University_ID,Difficulty_ID,Course_URL_ID
FROM METADATA
WHERE Record_ID = 159
SELECT [Record_ID]
      ,[Course_Name]
      ,[University]
      ,[Difficulty_Level]
      ,[Course_Rating]
      ,[Course_URL]
      ,[Course_Description]
      ,[Skills]
FROM @result1 as res
INNER JOIN [BDS].[dbo].[Two_WayShared_Course_Description] as DEScrip ON res.D_ID = DEScrip.Course_Desc_ID
INNER JOIN [BDS].[dbo].Two_WayShared_Skills as Skills ON res.S_ID = Skills.Skills_ID
INNER JOIN [BDS].[dbo].Four_WayShared_Course_Name as Course_Name ON res.Name_ID = Course_Name.Course_Name_ID
INNER JOIN [BDS].[dbo].Eight_WayShared_University as University ON res.U_ID = University.University_ID
INNER JOIN [BDS].[dbo].Eight_WayShared_Difficulty as Difficulty ON res.D_ID = Difficulty.Difficulty_ID
INNER JOIN [BDS].[dbo].Four_WayShared_Course_URL as URLs ON res.C_ID = URLs.Course_URL_ID
INNER JOIN [BDS].[dbo].PrivateNode as PrN ON res.id = PrN.Record_ID







