EXEC sp_spaceused Coursera_BDS;  
EXEC sp_spaceused Two_WayShared_Course_Description; 