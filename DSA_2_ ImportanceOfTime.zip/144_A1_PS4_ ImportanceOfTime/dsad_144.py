# import sys library for error handling
import sys

#Function pushProcess to push process at back of Queue(List)
def pushProcess(callingQueueParam):
    global timeTaken
    global callingQueue
    callingQueue = callingQueueParam
    outputFile.write("PUSH " + str(callingQueue[0]) + "\n")
    callingQueue = callingQueue[1:len(callingQueue)] + callingQueue[0:1]
    timeTaken += 1

#Function popProcess to pop process from front of the Queue(List)
def popProcess(idealQueueParam,callingQueueParam):
    global timeTaken
    global callingQueue
    global idealQueue
    idealQueue = idealQueueParam
    callingQueue = callingQueueParam
    idealProcess = str(idealQueue.pop(0))
    callingProcess = str(callingQueue.pop(0))
    outputFile.write("POP " + callingProcess + "\n")
    timeTaken += 1

#Check root directory programmatically
#import os
#print(os.path.dirname(os.path.abspath(__file__)))

#read input from text file inputPS4.txt into a variable 'inputFile'
#input file should be placed in root directory before program execution to avoid OS errors
try:
    inputFile = open("inputPS4.txt",'r')
except OSError as err:
    sys.exit("OS error: {0}".format(err))
except:
    sys.exit("Unexpected error:", sys.exc_info()[0])

#open text file outputPS4.txt with write privileges. Assign it to a variable 'outputFile'
try:
    outputFile = open("outputPS4.txt",'w')
except OSError as err:
    sys.exit("OS error: {0}".format(err))
except:
    sys.exit("Unexpected error:", sys.exc_info()[0])

# read in first line from input file into variable 'numberOfProcesses'
temp = inputFile.readline()
try:
    numberOfProcesses = int(temp[temp.index(":") + 1:len(temp)])
except ValueError:
    sys.exit("Could not convert data to an integer.")

# assign second line from the input file to the variable 'callingQueue'
temp1 = inputFile.readline()
temp2 = temp1[temp1.index(":") + 1:len(temp1)].split()
callingQueue = list(map(int, temp2))
if numberOfProcesses != len(callingQueue):
    sys.exit("No. of processes do not match with total processes in calling queue. Please correct and try again.")

# assign third line from the input file to the variable 'idealQueue'
temp3 = inputFile.readline()
temp4 = temp3[temp3.index(":") + 1:len(temp3)].split()
idealQueue = list(map(int, temp4))
if numberOfProcesses != len(idealQueue):
    sys.exit("No. of processes do not match with total processes in ideal queue. Please correct and try again.")

# Initialize time complexity counter to zero. Variable 'timeTaken'
timeTaken = 0

#while loop to execute queue operations till calling_order_queue is empty
#if first process in calling queue does not match with first process in idealQueue then pop first process
#in the calling queue and push it at the end of the calling queue
#if first process in calling queue matches with first process in idealQueue then pop first process
#in both the queues
# for each pop and push operations increment timeTaken by 1
def main():
    while(len(callingQueue) > 0):
        if(callingQueue[0] != idealQueue[0]):
            pushProcess(callingQueue)
        if(callingQueue[0] == idealQueue[0]):
            popProcess(idealQueue,callingQueue)

#Execute main function
main()

#Write total time taken to output file and close the files
try:
    outputFile.write("Total Time: " + str(timeTaken))
except OSError as err:
    sys.exit("OS error: {0}".format(err))
finally:
    # close both files
    inputFile.close()
    outputFile.close()