# import sys library for error handling
import sys

#read input from text file inputPS11.txt into a variable 'inputFile'
#input file should be placed in root directory before program execution to avoid OS errors
try:
    inputFile = open("inputPS11.txt",'r')
except OSError as err:
    sys.exit("OS error: {0}".format(err))
except:
    sys.exit("Unexpected error:", sys.exc_info()[0])

#open text file outputPS11.txt with write priviledges. Assign it to a variable 'outputFile'
try:
    outputFile = open("outputPS11.txt",'w')
except OSError as err:
    sys.exit("OS error: {0}".format(err))
except:
    sys.exit("Unexpected error:", sys.exc_info()[0])

# read in first line from input file into variable 'variety'
temp = inputFile.readline()
try:
    variety = int(temp[temp.index(":") + 1:len(temp)])
except ValueError:
    sys.exit("Could not convert data to an integer.")

# assign second line from the input file to the variable 'denominations'
temp1 = inputFile.readline()
temp2 = temp1[temp1.index(":") + 1:len(temp1)].split()
denominations = list(map(int, temp2))
if variety != len(denominations):
    sys.exit("No. of denominations do not match with total variety. Please correct and try again.")

# assign third line from the input file to the variable 'purchase'
temp3 = inputFile.readline()
try:
    purchase = int(temp3[temp3.index(":") + 1:len(temp3)])
except ValueError:
    sys.exit("Could not convert data to an integer.")

# Fun Fair implementation using Dynamic Programming
def noOfCombinations(Den, var, pur):
    # The table is built with n+1 rows to start with zero
    table = [[0 for x in range(var)] for x in range(pur + 1)]

    # Insert values starting with purchase value = 0
    for i in range(var):
        table[0][i] = 1

    # Insert the remaining cases by indexing purchase value by 1
    for i in range(1, pur + 1):
        for j in range(var):
            # Evaluating combinations with Den[j]
            a = table[i - Den[j]][j] if i - Den[j] >= 0 else 0

            # Evaluating of combinations without Den[j]
            b = table[i][j - 1] if j >= 1 else 0

            # total combinations
            table[i][j] = a + b

    return table[pur][var - 1]

# Call the function
possibleCombinations = noOfCombinations(denominations,variety,purchase)

#Write possible combinations to output file and close the files
try:
    outputFile.write("Possible Combinations: " + str(possibleCombinations))
except OSError as err:
    sys.exit("OS error: {0}".format(err))
finally:
    # close both files
    inputFile.close()
    outputFile.close()